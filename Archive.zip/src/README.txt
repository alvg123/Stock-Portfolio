This program version, 2.1.0, has added the controller.AbstractController abstract class,
controller.AdvanceStockController,  model.AdvancePortfolio, model.AdvPortfolioInterface interface
model.PortBalance interface, model.PortBalImpl class, model.StockTransaction,
model.StockTransactionImpl, view.ViewAdvanced, and view.ViewAdvancedImpl. This program and its
entirety of its contents was created by Steven Godinez and Alex Voung on Wednesday, June 12 2024.

# note no changes were made on existing code, just extensions were made.

# in version 2.1.0
The controller.AdvanceStockController is in charge of holding the implementations for the program. New
features were added such as, xml portfolio, We decided on xml instead of our initial implementation
of JSON file because we decided for user friendly-ness, instead of a user downloading the latest
JSON.jar file and instead of coding our own JSON parser, we decided to just use built in JDK tools
such as XML. Other feature added are portfolio value, buy stock, sell stock, portfolio composition,
portfolio distribution, portfolio re-balance and portfolio chart. Once again all the features
existing in version 1.1.0 are compatible and working in this version. Same details apply:
The AdvanceStockController creates a model object of the previous version to call back old features.
the old functions still stand as an API call to a free stock API, from the LLC Alpha Vantage.
These calls that are made in the following code were provided by the free code
accessed from one of the original creators of this program, Steven Godinez and Alex Vuong,
please fill free to get your own free api code at https://www.alphavantage.co/ The Api used in
this program returns the date, opening, high, low, closing market price, and volume in a CSV file.
features and purposes:

        # Version 1.1.0 : Scroll down to see Version 2.1.0  (line 61)
    - execute() : Initializes program with no parameters and allows the for the following features.
                  if inputted a number and enter, it considers that as the amount of days to call
                  back, followed by a Stock Ticker and enter, creating an API call of that stock
                  and saving it to a csv file. Once stock(s) exist in a csv file a user will have
                  the options of inputting different commands in the TUI(text user interface).
                  The first command the user will have access to is the gain or loss feature.
                  Feature can be accessed by entering number of day, followed by Ticker.

                  The gain or loss command feature allows a user to examine the gain or loss of a
                  stock over a specified period. The gain or loss feature will input ticker,
                  starting date and  end date in 'yyyy-mm-dd' format. please note the end date will
                  be the most recent date.
                  Feature can be accessed by entering 'g' enter, followed by Ticker, starting date,
                  and end date.

                  The moving average command feature allows a user to examine the x-day moving
                  average of a  stock for a specified date and a specified value of x. The method
                  will take in ticker, date and amount of days to go backwards. Note: date will
                  have to be passed in format 'yyyy-mm-dd'.
                  Feature can be accessed by entering 'm', followed by Ticker, date, and days.

                  The crossovers command feature allows a user to determine which days are x-day
                  crossovers for a specified stock over a specified date range and a specified
                  value of x. This feature takes in the stock ticker, starting date, end date, and
                  amount of days to check between ranges. Note: date will have to be passed in
                  format 'yyyy-mm-dd'
                  Feature can be accessed by entering 'c', followed by ticker, starting date, end
                  date, days.

                  The Portfolio creation command features allows a user to create as many Portfolios
                  and add as many Tickers into the Portfolio as possible. They can exit out of this by
                  pressing 'f', and when they want to see the value of the Portfolio, then the user can
                  enter a date, and its value of the Portfolio.

                  The user can reuse all these commands and if the user wants to quit using the Program,
                  they can press 'q'.

                  # Features in Version 2.1.0

                  The updated Portfolio creation command feature allows a user to create as many
                  empty portfolios and saves them to the directory of the user's choice. We decided
                  to limit the user to only saving portfolios in res, out, src. We also changed the
                  portfolio type from csv to XML. The XML is composed of portfolio name, and stocks
                  where a stock represents, ticker, date, closing price, and amount of stock.

                  The portfolio value method returns the value of a portfolio at a given date.
                  It does not matter what stock it is, as long as the date matches, the method
                  calculates the value of all stock and amount of stock, and returns that value.
                  If no date matches, method returns zero.

                  The Buy stock command allows a user to create a stock and assign it to an existing
                  portfolio. The user has to input ticker, date, and amount of stock and controller
                  will return the cost of a single cost and the total cost a user spent to buy that
                  stock. This method will overwrite the existing portfolio XML to add that stock.

                  The Sell Stock command allows a user to sell a specific amount of stock from an
                  existing portfolio. The user has to input, portfolio name, portfolio location,
                  date, ticker, amount of stock to sell. If user inputs an amount greater than total
                  amount of current stock, the program will sell all stock associated with that
                  ticker. This method overwrites XML portfolio file and removes that file / updates
                  the amount of stocks.

                  The Composition command allows a user to view the composition of a stock on a given
                  date. A user will input date, location, date and console will return stocks that
                  match that date and the amount of stock that goes with it.

                  The Distribution Command is similar to composition but instead of returning stock
                  and amount of stock. This method returns the total monetary value of all the
                  stocks at a given date, and calculates the percentage of composition compared to
                  the entirety of the portfolio. Where the entire portfolio is 100% of the value
                  and the days that match get their price calculated according to their price and
                  amount which in term returns the percentage of 100 that it builds up. Also showing
                  the percentage that all the matching dates add up to out of 100 and their added
                  price.

                  The Re-balance command allows a user to access a specific portfolio, assign it a
                  budget and one by one assign each stock of different date, a percentage of the
                  total budget it should be. All percentages must add to 100. Note that the program
                  will display the percentage left to reach 100. This was built in hopes of if a
                  user buys or sells stocks and that assigned percentage changes, the re-balance
                  will automatically buy / sells stocks even at fractions in order to satisfy both
                  percentages and staying within budget.

                  The Chart commands allows a user to input a stock or a portfolio and a date range
                  in which to access said object in order to display growth or decay of a given
                  stock / portfolio through asterisk that automatically compute a key value to
                  assign said asterisk. Note the method may return anywhere from 5 to 30 lines.
                  if given any range below 5 days, not enough information error will be thrown, as
                  the API call in this program is daily and cannot return by the hour.




The model.AdcPortfolioInterface Interface offers the user various methods in which they could get
to edit a model.AdvancePortfolio
    - savePorts(String filePlace) : creates and saves empty portfolio
    - purchaseAddStock(String date, String ticker,int shares) : purchases stock on given information
    - sellRemoveStock(String date, String ticker, int shares, String filePath): sells / removes stock
                                                                                on given information.
    - displayComposition(String date) : returns the composition of a stock at a given day.
    - valueOfPortfolio(String date) :  gets the value of stock at a given day
    - getDistribution(String date) : returns the distribution of stock within that date
    - addSavePorts(String filePlace): overwrites XML file to add a stock/ update stock
    - loadPortfolio(String portfolioPath, String portfolioName): loads a portfolio into a Portfolio
                                                                 object from given information
Classes that implement this interface as of Wednesday, January 12th are as follows.
    - model.AdvancePortfolio
Methods in this class seem to work fine.


// here






The model.StockModelImpl class functions as our representation of the given stock methods.
Inheriting the methods from the parent interface allows one to get the individual fields.
Features and usage include:
    - getDate() :   get for the date field.
    - getOpen() :   get for the opening price field on x day.
    - getHigh() :   get for the high of the field on x day.
    - getLow() :    get the low of the file on x day.
    - getClose() :  get the closing price of the field on x day.
    - getVolume() : get the volume of the file on x day.
    - daysCrossover(String ticker, String startingDate, String endDate, int days) :
                    gets the days that crossover in the market.
    - movingDayAverage(String ticker, String endDate, int days) :
                    gets the moving day average number of a stock given the date and the amount of
                    dates to go back to check.
    - gainOrLoss(String ticker, String startingDate, String endDate) :
                    gets the gain or loss value of a stock between a specific date range.
    - fixDateOrder(String startingDate, String endDate) :
                    gets the correct date order for which to measure date ranges.
Methods in this class work.

The model.Stock class functions as our representation of a stock. Inhering methods from the parent
stock interface, model.GeneralStock, allows the user to gain getters. this class allows the user
to initialize stocks.
Features and Usage include:
    - getTicker() : gets the ticker of the stock.
    - getDate() :   gets the date of the stock.
    - getOpen() :   gets the opening price of the stock.
    - getHigh() :   gets the high of the given day of the stock.
    - getLow() :    gets the low of the given day of the stock.
    - getClose() :  gets the closing price of the given day of the stock.
    - getVolume() : gets the volume of the given stock.
    - initializeStockFromTicker(String ticker) :
                    Initializes the stock with the given parameters called by the API.
    - getValueOnDate(String date, String portfolioName) :
                    gets the value of a stock on a given day and on a given portfolio. This feature
                    is a helper to the 'p4' command feature.
Methods in this class work.

The model.Portfolio class functions as our representation of a stock portfolio. Inhering methods
from the parent portfolio interface, model.GeneralPortfolio, allows the user to gain portfolio
features. This class allows a user to treat portfolios as they choose.
Features and Usage include:
    - getName() :       gets the name of the portfolio.
    - getConsStock() :  gets the list of stock of the portfolio.
    - stocksAddCreatePortfolio(String name, List<String> ticker, List<Stock> stocks):
                        creates a new portfolio in which stocks passed are added.
    - stockGet(List<String> ticker, List<Stock> stocks) :
                        returns list of stock that match ticker and list of stocks.
    - savePortfolio() : saves portfolio changes to CSV file, updating the program.
    - removeStocksFromExistingPortfolio(String ticker):
                        removes stock from an already existing folder.
    - addStockToExistingPortfolio(String ticker, List<Stock> stocks) :
                        adds stock to given portfolio. Feature implements a silent field that user
                        will never see in the TUI.
    - valueOfPortfolio(String date) :
                        gets the value of a portfolio at a given date.
Methods of this class are buggy.

The view.ViewImpl class functions as our representation of the view class from the MVC control
pattern. Inheriting methods from the view interface, view.view, the methods mostly pertain to some
sort of System outprint:
Features and Usage include:
    - display(String message) :      displays current message passed.
    - displayWelcomeMessage() :      displays welcome message.
    - displayEnterTicker() :         displays ticker of a company that already exist within
                                     program's api call.
    - displayEnterStartingDate() :   displays the entering start date inputted.
    - displayEnterEndingDate() :     displays the ending date that already exist within program.
    - displayButHasNum(double num) : displays the double that is passed in.
    - displayDate() :                displays to ask to input a date message.
    - displayDays() :                displays an input amount of days.
    - displayNumDaysInvalidInput() : displays amount days as invalid.
    - displayNamingPortfolio() :     displays an input to name a portfolio.
    - displayEnterTickerS() :        displays an input tickers message.
Methods of this class work.