# Running the Stock Simulation Program Created by Steven Godinez and Alex Voung.

1. Please download the java jar zip.

2. place jar in a directory of your running preferred IDE.

3. Run the program from terminal.

# Creating a Portfolio

To create a portfolio with 3 different stocks:

1. Run the program as described above.

2. Enter amount of days to back track.

3. Enter desired Company ticker.

4. Repeat two more times with different tickers.

4. Enter 'p1'

5. Enter Portfolio desired name.

6. Enter Ticker1, shares of Ticker1, Ticker2 shares of Ticker2, Ticker3 shares of Ticker3

7. Enter 'f' to back track.

8. Enter date if you want to see portfolio value at some date or enter 'f' again to backtrack from p1 feature

# NOTE # : quitting program in version 1.1.0 will kill progress, to see if portfolio was created just enter date to find
portfolio existence, enter date to find value at specifc day.

To create a second portfolio with 2 different stocks, repeat the steps above, but enter `2` for number of shares.

# Querying a Portfolio's Value

To query the value of a portfolio on a specific date:

1. Run the program as described above.

2. enter 30 for days, ticker GOOG, press 'p1', enter name, enter GOOG, enter 10, enter 'f',  enter 2024-06-05
this will prompt a value of 1770.6999999999998


# Supported Stocks (stocks that already exist)

The program supports the following stocks:

- GOOG: Available data from 2014-03-27 to 2024-06-06
- META: Available data from 2012-05-18 to 2024-06-06
- MMM: Available data from 2024-05-31 to 2024-06-06

Please note that the program may not be able to determine the value of a stock on a date for which data is not
available. Furthermore, p2-p4 are yet to be implemented in version 1.1.0 in this program.


# Version 2.1.0

 Download JSON library from Maven repository, latest version "json-20230303.jar" and add it as a
 dependency in file structure (intellij) under the model class.