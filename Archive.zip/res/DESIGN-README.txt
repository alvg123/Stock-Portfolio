The design of the Stock Simulator. The stock Simulator program follows and MVC, model, view , and
controller, implementation that uses the main method, StockProgram to initialize. Note this is an
extension of version 1.1.0, currently in version 2.1.0, no changes was made on existing code but
instead just extended

                             ----- The controller -----
# Version 1.1.0
This package is on the API caller that handles the calls and the different key inputs. There exist
a void executes that has the features nested. A user is given a variety of commands to choose from
that access both the model and the view packages. Each character case, if found to be true,
immediately calls the view to display the correct next message for the next input. After each input the
model is called to pass some sort of action to be displayed later. We used a scanner in order to read the
user's input before delegating them to their corresponding classes. We did decide to hardcode the API key as we
believed it would have been easier for the user to just use the program without having to worry
about creating the new key / inputting a new key. Within this controller class we have some code
that does test for edge cases however not all extreme edge cases are accounted for. While the
program does do API calls we have implemented checkers to see if a csv file for that stock exist. If
a file exist and the amount of days supersedes the new days in which you are trying to call, no API
call is called. This was done to remove coupling between user/program and internet use. We aspired
to model this program to be as least depending on the internet as possible. All methods are
delegated to the controller to satisfy CMV. The controller is composed of one main interface holding
the main method.

# Version 2.1.0
This package, on top of its already existing implementation now has a new advance controller that
calls on an abstract in which objects of the older controller are referenced in order to produce
previous features results. New features are also in the abstract named do{nameHere}() so our
advanced controller, which extends the abstract can just call the methods as this.do{nameHere}
in a switch statement to be organized and to keep the switch short. The advance stock controller
is implemented by only having one execute method which is called in the StockProgram class to
initialize the program.

                                ----- The model -----
# Version 1.1.0
This package is in charge of StockModelImpl class, and portfolio objects as well as the methods that go
behind the assignment. The model is the heart of our simulation. The Portfolio class is designed in
such a way to avoid mutation as much as possible and instead create new objects with the updated
fields through private helpers and return those new portfolios/CSV which replace the already
existing ones. This gives the illusion of a sort of mutation when in reality the process just mask
object-oriented design by creating new immutable objects. The StockModelImpl class aims to have a
similar approach of minimal mutation. This class implements a few java libraries for easier implementation.
The StockModelImpl is the core of our data analytics, it is in charge of stock related calculations.
Meanwhile, the Portfolio class manages the portfolio related operations. The model is composed of two
interfaces that the stock and portfolio implement

# Version 2.1.0
This package, on top of its already existing implementation now has a new AdvancedPortfolio class that
takes care of editing the portfolios. These methods are void but don't necessarily mutate. It is more
accurate to describe the buy and sell as methods that override the existing XML portfolio returning
a new portfolio object. Of course this is paired up with an interface with its methods. We also
implemented PortBalImpl class that is meant to take in more paramaters, such as budget, composition
of a stockTransactionImpl object, etc in order to perform rebalance feature. It was much easier to
track of all the information in a new more advanced object after call the existing save portfolio
methods to override the XML to perform the rebalance. /// more asd fasdfasdf asd fasd fasd f sf

                                ----- The view -----
# Version 1.1.0
This view is in charge of the TUI. Although the following program is not a GUI, we have chosen to
include this as a future implementation of this program could be GUI. However, the view mostly
takes care of the output messages, which is called in the controller, that prompt a user to input
the next command and also is in charge of outputting the messages called by model methods'. Overall,
this package is the smallest as it does not do much however the controller is very much coupled with the view.