import java.io.InputStreamReader;
import controller.APIController;
import controller.AdvanceStockController;
import model.StockModel;
import model.StockModelImpl;
import view.ViewAdvanced;
import view.ViewAdvancedImpl;
import controller.AlphaVantageAPICallController;
import view.View;
import view.ViewImpl;

/**
 * Runs the program of the features that involve stock simulation.
 */
public class StockProgram {

  /**
   * connects the text-based interface(view), implemented features(model),
   * and the inputs by the user(controller). With new Portoflio features.
   *
   * @param args is how many days you want to go backwards to, to see that stocks,
   *             and the ticker of the company that you want to see their stocks.
   */
  public static void main(String[] args) {
    StockModel model = new StockModelImpl();
    ViewAdvanced view = new ViewAdvancedImpl(System.out);
    Readable in = new InputStreamReader(System.in);
    APIController controller = new AdvanceStockController(model, view, in);
    controller.execute();
  }


  /**
   * connects the text-based interface(view), implemented features(model),
   * and the inputs by the user(controller).
   *
   * @param args is how many days you want to go backwards to, to see that stocks,
   *             and the ticker of the company that you want to see their stocks.
   */
  public static void oldMain(String[] args) {
    StockModel model = new StockModelImpl();
    View view = new ViewImpl(System.out);
    Readable in = new InputStreamReader(System.in);
    APIController controller = new AlphaVantageAPICallController(model, view, in);
    controller.execute();
  }


}


